﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hw4_lottery
{
    public partial class Form1 : Form
    {
        List<Button> myDbutton_list = new List<Button>();
        List<string> Clickbuttons_list = new List<string>();
        Button[] arrayBtn24_num = new Button[24];
        List<int> list_matchnum = new List<int>();
        int[] arraylottoset1 = new int[12];
        int[] arraylottoset2 = new int[12];
        int[] arraylottoset3 = new int[12];
        int k = 1;
        bool p = false;
        string[] arraybtn_num = new string[24];
        int[] arrayRndNums = new int[12];
        int[] arraytest = new int[12];
        string[] array_insert = new string[12];




        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            changeable_produce_btn(4, 6);
            myDbutton_list.Clear();
            lblbet1.Text = lblbet2.Text = lblbet3.Text = lblwin_num.Text = "";
        }
        //string strmessage = "";

        void dbutton_Click(object sender, EventArgs e)
        {
            Button mybutton = (Button)sender;
            bool ifselected = false;
            if ((myDbutton_list.Count < 12) && (ifselected == false))
            {
                if (mybutton.BackColor == Color.Green)
                {
                    mybutton.BackColor = Color.LightGreen;
                    myDbutton_list.Add(mybutton);
                    //strmessage += mybutton.Text + " ";

                }
                else
                {
                    mybutton.BackColor = Color.Green;
                    myDbutton_list.Remove(mybutton);
                }
            }
            else
            {
                if (mybutton.BackColor == Color.LightGreen)
                {
                    mybutton.BackColor = Color.Green;
                    myDbutton_list.Remove(mybutton);
                }
            }

        }

        void changeable_produce_btn(int intcount1, int intcount2)
        {
            for (int i = 0; i < intcount1; i += 1)
            {
                for (int j = 0; j < intcount2; j += 1)
                {
                    Button dbutton = new Button();
                    dbutton.BackColor = Color.Green;
                    dbutton.ForeColor = Color.BlanchedAlmond;
                    dbutton.Text = k++.ToString();
                    //dbutton.TextAlign = 
                    dbutton.Name = "btn" + i.ToString() + "-" + j.ToString();
                    dbutton.Font = new Font("微軟正黑體", 10);
                    dbutton.Size = new Size(35, 35);
                    dbutton.Location = new Point(90 + 62 * j, 150 + 42 * i);
                    dbutton.Click += new EventHandler(dbutton_Click);

                    Controls.Add(dbutton);
                    myDbutton_list.Add(dbutton);

                }
            }
            myDbutton_list.CopyTo(arrayBtn24_num);
        }

        public void btnrnd_num_Click(object sender, EventArgs e)
        {
            produceRndNum();

            foreach (Button Numbers in arrayBtn24_num)
            {
                Numbers.BackColor = Color.Green;
            }

            Array.Sort(arrayRndNums);
            myDbutton_list.Clear();

            foreach (int RndNum in arrayRndNums)
            {
                arrayBtn24_num[RndNum - 1].BackColor = Color.LightGreen;
                myDbutton_list.Add(arrayBtn24_num[RndNum - 1]);
            }

        }
        void produceRndNum()
        {
            Random myRndNum = new Random();
            int tempRndNum = 0;
            bool ifDuplicate = false;

            arrayRndNums[0] = myRndNum.Next(1, 25);
            for (int i = 1; i < 12; i += 1)
            {
                tempRndNum = myRndNum.Next(1, 25);
                ifDuplicate = arrayRndNums.Contains(tempRndNum);
                for (int j = 0; j < 12 ; j += 1)
                {
                    if (ifDuplicate == true)
                    {
                        tempRndNum = myRndNum.Next(1, 25);
                        ifDuplicate = arrayRndNums.Contains(tempRndNum);
                    }
                    else
                    {
                        arrayRndNums[i] = tempRndNum;
                    }
                }
            }
        }

        private void btnsignup_Click(object sender, EventArgs e)
        {
            if (myDbutton_list.Count == 12)
            {

                if (lblbet1.Text == "")
                {

                    for (int i = 0; i < 12; i++)
                    {
                        arraylottoset1[i] = Convert.ToInt32(myDbutton_list[i].Text);
                    }
                    Array.Sort(arraylottoset1);
                    foreach (Button mybutton in myDbutton_list)
                    {

                        lblbet1.Text += mybutton.Text.ToString() + " ";
                    }
                }
                else if (lblbet2.Text == "")
                {
                    for (int i = 0; i < 12; i++)
                    {
                        arraylottoset2[i] = Convert.ToInt32(myDbutton_list[i].Text);
                    }
                    Array.Sort(arraylottoset2);
                    foreach (Button mybutton in myDbutton_list)
                    {
                        lblbet2.Text += mybutton.Text.ToString() + " ";
                    }
                }
                else if (lblbet3.Text == "")
                {
                    for (int i = 0; i < 12; i++)
                    {
                        arraylottoset3[i] = Convert.ToInt32(myDbutton_list[i].Text);
                    }
                    Array.Sort(arraylottoset3);
                    foreach (Button mybutton in myDbutton_list)
                    {
                        lblbet3.Text += mybutton.Text.ToString() + " ";
                    }
                }

            }
            else
            {
                MessageBox.Show("請選擇\"12\"個號碼，或 由電腦選號下注");
            }

            //lblbet1.Text = strmessage;

        }
        private void btn開獎_Click(object sender, EventArgs e)
        {
            produceRndNum();

            Array.Sort(arrayRndNums);

            if (lblwin_num.Text=="")
            {
                foreach (int Num in arrayRndNums)
                {
                    lblwin_num.Text += Num.ToString() + " ";
                }
            }
            else
            {
                lblwin_num.Text = "";
                foreach (int Num in arrayRndNums)
                {
                    lblwin_num.Text += Num.ToString() + " ";
                }
            }
            
        }
        private void btnmatch_Click(object sender, EventArgs e)
        {
            lblmatching_consequence.Text = "";
            if (lblfinal_match.Text != "")
            {
                lblfinal_match.Text = "";
            }
            else
            {

                if ((lblbet1.Text != "") && (myDbutton_list.Count() > 0))
                {
                    //lblfinal_match.Text = "000000000000";
                    if ((arrayRndNums.Intersect(arraylottoset1).Count() == 12) || (arraylottoset1.Intersect(arrayRndNums).Count() == 0))
                    {
                        lblfinal_match.Text += "\n***恭喜您第一注中頭獎***\n " + "總共 : " + arrayRndNums.Intersect(arraylottoset1).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset1.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                        MessageBox.Show("冷靜!莫急莫慌請先閱讀完以下彩金分配原則: \n" + "\n若頭獎中獎下注數<3，則每注可獲得1500萬元的獎金\n"
                            + "\n若頭獎中獎下注數>3，則總獎金4500萬元除以總注數，並按頭獎的下注數分配獎金予各位中獎者");
                    }
                    else if ((arrayRndNums.Intersect(arraylottoset1).Count() == 11) || (arrayRndNums.Intersect(arraylottoset1).Count() == 1))
                    {
                        lblfinal_match.Text += "\n***恭喜您第一注中貳獎***\n " + "獲得獎金十萬元\n" + "總共 : " + arrayRndNums.Intersect(arraylottoset1).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset1.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                    }
                    else if ((arrayRndNums.Intersect(arraylottoset1).Count() == 10) || (arrayRndNums.Intersect(arraylottoset1).Count() == 2))
                    {
                        lblfinal_match.Text += "\n***恭喜您第一注中參獎***\n " + "獲得獎金五百元\n" + "總共 : " + arrayRndNums.Intersect(arraylottoset1).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset1.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                    }
                    else if ((arrayRndNums.Intersect(arraylottoset1).Count() == 9) || (arrayRndNums.Intersect(arraylottoset1).Count() == 3))
                    {
                        lblfinal_match.Text += "\n***恭喜您第一注中肆獎***\n " + "獲得獎金一百元\n" + "總共 : " + arrayRndNums.Intersect(arraylottoset1).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset1.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                    }

                }
                if ((lblbet2.Text != "") && (myDbutton_list.Count() > 0))
                {

                    if ((arrayRndNums.Intersect(arraylottoset2).Count() == 12) || (arraylottoset2.Intersect(arrayRndNums).Count() == 0))
                    {
                        lblfinal_match.Text += "\n***恭喜您第二注中頭獎***\n " + "總共 : " + arrayRndNums.Intersect(arraylottoset2).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset2.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                        MessageBox.Show("冷靜!莫急莫慌請先閱讀完以下彩金分配原則: \n" + "\n若頭獎中獎下注數<3，則每注可獲得1500萬元的獎金\n"
                            + "\n若頭獎中獎下注數>3，則總獎金4500萬元除以總注數，並按頭獎的下注數分配獎金予各位中獎者");
                    }
                    else if ((arrayRndNums.Intersect(arraylottoset2).Count() == 11) || (arrayRndNums.Intersect(arraylottoset2).Count() == 1))
                    {
                        lblfinal_match.Text += "\n***恭喜您第二注中貳獎***\n " + "獲得獎金十萬元\n" + "總共 : " + arrayRndNums.Intersect(arraylottoset2).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset2.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                    }
                    else if ((arrayRndNums.Intersect(arraylottoset2).Count() == 10) || (arrayRndNums.Intersect(arraylottoset2).Count() == 2))
                    {
                        lblfinal_match.Text += "\n***恭喜您第二注中參獎***\n " + "獲得獎金五百元\n" + "總共 : " + arrayRndNums.Intersect(arraylottoset2).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset2.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                    }
                    else if ((arrayRndNums.Intersect(arraylottoset2).Count() == 9) || (arrayRndNums.Intersect(arraylottoset2).Count() == 3))
                    {
                        lblfinal_match.Text += "\n***恭喜您第二注中肆獎***\n " + "獲得獎金一百元\n" + "總共 : " + arrayRndNums.Intersect(arraylottoset2).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset2.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                    }

                }
                if ((lblbet3.Text != "") && (myDbutton_list.Count() > 0))
                {

                    if ((arrayRndNums.Intersect(arraylottoset3).Count() == 12) || (arraylottoset3.Intersect(arrayRndNums).Count() == 0))
                    {
                        lblfinal_match.Text += "\n***恭喜您第三注中頭獎***\n " + "總共 : " + arrayRndNums.Intersect(arraylottoset3).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset3.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                        MessageBox.Show("冷靜!莫急莫慌請先閱讀完以下彩金分配原則: \n" + "\n若頭獎中獎下注數<3，則每注可獲得1500萬元的獎金\n"
                            + "\n若頭獎中獎下注數>3，則總獎金4500萬元除以總注數，並按頭獎的下注數分配獎金予各位中獎者");
                    }
                    else if ((arrayRndNums.Intersect(arraylottoset3).Count() == 11) || (arrayRndNums.Intersect(arraylottoset3).Count() == 1))
                    {
                        lblfinal_match.Text += "\n***恭喜您第三注中貳獎***\n " + "獲得獎金十萬元\n" + "總共 : " + arrayRndNums.Intersect(arraylottoset3).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset3.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                    }
                    else if ((arrayRndNums.Intersect(arraylottoset3).Count() == 10) || (arrayRndNums.Intersect(arraylottoset3).Count() == 2))
                    {
                        lblfinal_match.Text += "\n***恭喜您第三注中參獎***\n " + "獲得獎金五百元\n" + "總共 : " + arrayRndNums.Intersect(arraylottoset3).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset3.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                    }
                    else if ((arrayRndNums.Intersect(arraylottoset3).Count() == 9) || (arrayRndNums.Intersect(arraylottoset3).Count() == 3))
                    {
                        lblfinal_match.Text += "\n***恭喜您第三注中肆獎***\n " + "獲得獎金一百元\n" + "總共 : " + arrayRndNums.Intersect(arraylottoset3).Count() + "個號碼符合\n" + "此次中獎號碼: ";
                        foreach (int match in arraylottoset3.Intersect(arrayRndNums))
                        {
                            lblfinal_match.Text += match.ToString() + " ";
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            myDbutton_list.Clear();
            foreach (Button changecolor in arrayBtn24_num)
            {
                changecolor.BackColor = Color.Green;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblbet1.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            lblbet2.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lblbet3.Text = "";
        }
    }
}
