﻿namespace hw4_lottery
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnrnd_num = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblbet1 = new System.Windows.Forms.Label();
            this.lblbet3 = new System.Windows.Forms.Label();
            this.lblbet2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblwin_num = new System.Windows.Forms.Label();
            this.btnmatch = new System.Windows.Forms.Button();
            this.btnsignup = new System.Windows.Forms.Button();
            this.btn開獎 = new System.Windows.Forms.Button();
            this.lblmatching_consequence = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblfinal_match = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(77, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(370, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "~雙贏彩兌獎系統歡迎您~";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(23, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "雙贏彩投注號碼";
            // 
            // btnrnd_num
            // 
            this.btnrnd_num.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnrnd_num.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnrnd_num.ForeColor = System.Drawing.Color.Green;
            this.btnrnd_num.Location = new System.Drawing.Point(288, 326);
            this.btnrnd_num.Name = "btnrnd_num";
            this.btnrnd_num.Size = new System.Drawing.Size(102, 34);
            this.btnrnd_num.TabIndex = 2;
            this.btnrnd_num.Text = "系統選號";
            this.btnrnd_num.UseVisualStyleBackColor = false;
            this.btnrnd_num.Click += new System.EventHandler(this.btnrnd_num_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(23, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "自行選號";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(13, 382);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "第一組下注號碼";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.ForeColor = System.Drawing.Color.Navy;
            this.label5.Location = new System.Drawing.Point(13, 499);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "第三組下注號碼";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.ForeColor = System.Drawing.Color.Navy;
            this.label6.Location = new System.Drawing.Point(13, 443);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 24);
            this.label6.TabIndex = 6;
            this.label6.Text = "第二組下注號碼";
            // 
            // lblbet1
            // 
            this.lblbet1.Location = new System.Drawing.Point(162, 382);
            this.lblbet1.Name = "lblbet1";
            this.lblbet1.Size = new System.Drawing.Size(258, 30);
            this.lblbet1.TabIndex = 7;
            this.lblbet1.Text = "0";
            // 
            // lblbet3
            // 
            this.lblbet3.Location = new System.Drawing.Point(162, 502);
            this.lblbet3.Name = "lblbet3";
            this.lblbet3.Size = new System.Drawing.Size(258, 24);
            this.lblbet3.TabIndex = 8;
            this.lblbet3.Text = "0";
            // 
            // lblbet2
            // 
            this.lblbet2.Location = new System.Drawing.Point(162, 446);
            this.lblbet2.Name = "lblbet2";
            this.lblbet2.Size = new System.Drawing.Size(258, 24);
            this.lblbet2.TabIndex = 9;
            this.lblbet2.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.ForeColor = System.Drawing.Color.Teal;
            this.label10.Location = new System.Drawing.Point(22, 575);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 26);
            this.label10.TabIndex = 10;
            this.label10.Text = "本期中獎號碼";
            // 
            // lblwin_num
            // 
            this.lblwin_num.Location = new System.Drawing.Point(28, 617);
            this.lblwin_num.Name = "lblwin_num";
            this.lblwin_num.Size = new System.Drawing.Size(459, 54);
            this.lblwin_num.TabIndex = 11;
            this.lblwin_num.Text = "00000000000000000";
            // 
            // btnmatch
            // 
            this.btnmatch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnmatch.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnmatch.ForeColor = System.Drawing.Color.Green;
            this.btnmatch.Location = new System.Drawing.Point(417, 720);
            this.btnmatch.Name = "btnmatch";
            this.btnmatch.Size = new System.Drawing.Size(111, 52);
            this.btnmatch.TabIndex = 12;
            this.btnmatch.Text = "兌獎";
            this.btnmatch.UseVisualStyleBackColor = false;
            this.btnmatch.Click += new System.EventHandler(this.btnmatch_Click);
            // 
            // btnsignup
            // 
            this.btnsignup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnsignup.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnsignup.ForeColor = System.Drawing.Color.Green;
            this.btnsignup.Location = new System.Drawing.Point(426, 326);
            this.btnsignup.Name = "btnsignup";
            this.btnsignup.Size = new System.Drawing.Size(102, 34);
            this.btnsignup.TabIndex = 13;
            this.btnsignup.Text = "下注";
            this.btnsignup.UseVisualStyleBackColor = false;
            this.btnsignup.Click += new System.EventHandler(this.btnsignup_Click);
            // 
            // btn開獎
            // 
            this.btn開獎.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn開獎.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn開獎.ForeColor = System.Drawing.Color.Green;
            this.btn開獎.Location = new System.Drawing.Point(417, 589);
            this.btn開獎.Name = "btn開獎";
            this.btn開獎.Size = new System.Drawing.Size(111, 51);
            this.btn開獎.TabIndex = 14;
            this.btn開獎.Text = "開獎";
            this.btn開獎.UseVisualStyleBackColor = false;
            this.btn開獎.Click += new System.EventHandler(this.btn開獎_Click);
            // 
            // lblmatching_consequence
            // 
            this.lblmatching_consequence.AutoSize = true;
            this.lblmatching_consequence.Location = new System.Drawing.Point(41, 686);
            this.lblmatching_consequence.Name = "lblmatching_consequence";
            this.lblmatching_consequence.Size = new System.Drawing.Size(0, 21);
            this.lblmatching_consequence.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.ForeColor = System.Drawing.Color.Green;
            this.button1.Location = new System.Drawing.Point(147, 326);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 34);
            this.button1.TabIndex = 16;
            this.button1.Text = "清除重選";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblfinal_match
            // 
            this.lblfinal_match.AutoSize = true;
            this.lblfinal_match.Location = new System.Drawing.Point(23, 665);
            this.lblfinal_match.Name = "lblfinal_match";
            this.lblfinal_match.Size = new System.Drawing.Size(14, 21);
            this.lblfinal_match.TabIndex = 17;
            this.lblfinal_match.Text = ".";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.ForeColor = System.Drawing.Color.Green;
            this.button2.Location = new System.Drawing.Point(426, 382);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(106, 30);
            this.button2.TabIndex = 18;
            this.button2.Text = "重新投注";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button3.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.ForeColor = System.Drawing.Color.Green;
            this.button3.Location = new System.Drawing.Point(426, 502);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(106, 30);
            this.button3.TabIndex = 19;
            this.button3.Text = "重新投注";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button4.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button4.ForeColor = System.Drawing.Color.Green;
            this.button4.Location = new System.Drawing.Point(426, 443);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(106, 30);
            this.button4.TabIndex = 20;
            this.button4.Text = "重新投注";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(572, 1015);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lblfinal_match);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblmatching_consequence);
            this.Controls.Add(this.btn開獎);
            this.Controls.Add(this.btnsignup);
            this.Controls.Add(this.btnmatch);
            this.Controls.Add(this.lblwin_num);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblbet2);
            this.Controls.Add(this.lblbet3);
            this.Controls.Add(this.lblbet1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnrnd_num);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "雙贏彩";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnrnd_num;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblbet1;
        private System.Windows.Forms.Label lblbet3;
        private System.Windows.Forms.Label lblbet2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblwin_num;
        private System.Windows.Forms.Button btnmatch;
        private System.Windows.Forms.Button btnsignup;
        private System.Windows.Forms.Button btn開獎;
        private System.Windows.Forms.Label lblmatching_consequence;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblfinal_match;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}

